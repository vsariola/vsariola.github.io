## Patch Variables:

* __audio_fft__ ```Number```
* __audio_fft_array__ ```Array```
* __beat__ ```Number```
* __demo_length__ ```Number```
* __midi_a3__ ```Number```
* __mute__ ```Number```
* __palette__ ```Array```

