# konkretie - brainlez Coders!

apollo & pestis late night (morning) cables.gl sessions for the
mountainbytes 2023 24h fast challenge. music for the fast challenge
kindly contributed by glxblt. watch online:

https://vsariola.github.io/konkretie/

if you want to watch it on a local computer, e.g. python comes with a
nice tiny webserver: `python -m http.server`
