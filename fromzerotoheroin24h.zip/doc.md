## Patch Variables:

* __303__ ```Number```
* __audio_fft__ ```Number```
* __BASSHITS__ ```Number```
* __BD__ ```Number```
* __BPM__ ```Number``` (default Value: `132.000132000132`)
* __BREAKS__ ```Number```
* __demo_length__ ```Number```
* __midi_a3__ ```Number```
* __mute__ ```Number```
* __ORCHHIT__ ```Number```
* __overlay_show__ ```Number``` (default Value: `0`)
* __SD__ ```Number```
* __SHOUTS__ ```Number```
* __VOX__ ```Number```

